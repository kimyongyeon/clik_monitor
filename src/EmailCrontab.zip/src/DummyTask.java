/**
 * Created by kimyongyeon on 2016-09-28.
 */
public class DummyTask {
    public void print() {
        System.out.println("Spring 4.0 + Quartz 2.2 ");
    }
}
